# Treina com Hortêncio

Aplicação Android nativa de exercícios físicos, construída em Kotlin e Jetpack Compose.

## Estado

Fundação técnica inicial: projecto Android, tema Material 3, ecrã inicial, testes e CI.

## Abrir e compilar

1. Abrir a pasta no Android Studio.
2. Aguardar a sincronização do Gradle.
3. Executar a configuração `app`.
4. Para build local: `gradle test assembleDebug`.

Requisitos: JDK 17, Android SDK 36 e Gradle 8.13.
